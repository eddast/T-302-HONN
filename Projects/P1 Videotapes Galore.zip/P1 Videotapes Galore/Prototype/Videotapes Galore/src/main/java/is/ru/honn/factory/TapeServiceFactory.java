/*
 * @(#)TapeServiceFactory.java 1.0 26 Sep 2018 Edda Steinunn Rúnarsdóttir
 *
 * Copyright (c) Edda Steinunn Rúnarsdóttir
 */
package is.ru.honn.factory;

import is.ru.honn.service.TapeMemoryService;
import is.ru.honn.service.TapeService;

/**
 * Class TapeServiceFactory (TapeServiceFactory.java)
 * Gets static instance of tape service for classes to use
 *
 * @author Edda Steinunn Rúnarsdóttir
 * @version 1.0, 26 Sep 2018
 */
public class TapeServiceFactory
{
    /**
     * Static instance of tape service
     */
    private static TapeService tapeService = null;


    /**
     * Gets tape service for classes to use
     *
     * @return tape service
     */
    public static TapeService getTapeService()
    {
        if(tapeService == null)
        {
            Class c = BorrowProperties.getClassFromProperty("tape");
            try
            {
                tapeService = (TapeService) c.newInstance();
            }
            catch (InstantiationException e)
            {
                e.printStackTrace();
            }
            catch (IllegalAccessException e)
            {
                e.printStackTrace();
            }
        }
        return tapeService;
    }
}