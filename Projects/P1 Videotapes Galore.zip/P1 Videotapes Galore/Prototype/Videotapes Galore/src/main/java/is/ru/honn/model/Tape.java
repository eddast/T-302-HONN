/*
 * @(#)Tape.java 1.0 26 Sep 2018 Edda Steinunn Rúnarsdóttir
 *
 * Copyright (c) Edda Steinunn Rúnarsdóttir
 */
package is.ru.honn.model;

import java.util.Date;

/**
 * Class Tape (Tape.java)
 * Data type representing video tape
 *
 * @author Edda Steinunn Rúnarsdóttir
 * @version 1.0, 26 Sep 2018
 */
public class Tape
{
    /**
     * Tape id
     */
    private int id;
    /**
     * Title of tape
     */
    private String title;
    /**
     * Director of tape
     */
    private String director;
    /**
     * Tape type (VHS/Betamax)
     */
    private String type;
    /**
     * Date of release for tape
     */
    private Date releaseDate;
    /**
     * EIDR number of tape
     */
    private String EIDR;


    /**
     * Constructs a tape data type
     * @param title
     * @param director
     * @param type
     * @param releaseDate
     * @param EIDR
     */
    public Tape (int id, String title, String director, String type, Date releaseDate, String EIDR)
    {
        this.id = id;
        this.title = title;
        this.director = director;
        this.type = type;
        this.releaseDate = releaseDate;
        this.EIDR = EIDR;
    }
    /**
     * @return id of tape
     */
    public int getId()
    {
        return id;
    }
    /**
     * @return tape title
     */
    public String getTitle()
    {
        return title;
    }
    /**
     * @return tape director
     */
    public String getDirector()
    {
        return director;
    }
    /**
     * @return type of tape
     */
    public String getType()
    {
        return type;
    }
    /**
     * @param type new type for tape
     */
    public void setType(String type)
    {
        this.type = type;
    }
    /**
     * @return tape release date
     */
    public Date getReleaseDate()
    {
        return releaseDate;
    }
    /**
     * @return tape EIDR
     */
    public String getEIDR()
    {
        return EIDR;
    }
}
