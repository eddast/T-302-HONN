/*
 * @(#)BorrowRecord.java 1.0 26 Sep 2018 Edda Steinunn Rúnarsdóttir
 *
 * Copyright (c) Edda Steinunn Rúnarsdóttir
 */
package is.ru.honn.model;

import java.util.Date;

/**
 * Class BorrowRecord (BorrowRecord.java)
 * Data type representing a borrow record,
 * i.e. relation data type between friend and tape
 *
 * @author Edda Steinunn Rúnarsdóttir
 * @version 1.0, 26 Sep 2018
 */
public class BorrowRecord
{
    /**
     * id of person borrowing tape
     */
    private int borrowerID;
    /**
     * id of tape being borrowed
     */
    private int tapeID;
    /**
     * date of borrow
     */
    private Date borrowDate;
    /**
     * Date when the tape was returned, null if it hasn't been returned yet
     */
    private Date returnDate;

    /**
     * Empty constructor
     */
    public BorrowRecord()
    {

    }
    /**
     * Constructs a borrow record that has not been returned
     *
     * @param borrowerID id of person borrowing tape
     * @param tapeID id of tape being borrowed
     * @param borrowDate date of borrow
     */
    public BorrowRecord(int borrowerID, int tapeID, Date borrowDate)
    {
        this.borrowerID = borrowerID;
        this.tapeID = tapeID;
        this.borrowDate = borrowDate;
        this.returnDate = null;
    }
    /**
     * Constructs a borrow record with return date that has been returned
     *
     * @param borrowerID id of person borrowing tape
     * @param tapeID id of tape being borrowed
     * @param borrowDate date of borrow
     * @param returnDate date of return
     */
    public BorrowRecord(int borrowerID, int tapeID, Date borrowDate, Date returnDate)
    {
        this.borrowerID = borrowerID;
        this.tapeID = tapeID;
        this.borrowDate = borrowDate;
        this.returnDate = returnDate;
    }
    /**
     * @return email of person borrowing tape
     */
    public int getBorrowerID()
    {
        return borrowerID;
    }
    /**
     * @param borrowerID person borrowing tape's new email
     */
    public void setBorrowerID(int borrowerID)
    {
        this.borrowerID = borrowerID;
    }
    /**
     * @return borrowed tape's EIDR number
     */
    public int getTapeID()
    {
        return tapeID;
    }
    /**
     * @param tapeID borrowed tape's new EIDR number
     */
    public void setTapeID(int tapeID)
    {
        this.tapeID = tapeID;
    }
    /**
     * @return date of borrow for record
     */
    public Date getBorrowDate()
    {
        return borrowDate;
    }
    /**
     * @param borrowDate new date of borrow for record
     */
    public void setBorrowDate(Date borrowDate)
    {
        this.borrowDate = borrowDate;
    }
    /**
     * @return date of borrow for record
     */
    public Date getReturnDate()
    {
        return returnDate;
    }
    /**
     * @param returnDate new return date for record
     */
    public void setReturnDate(Date returnDate)
    {
        this.returnDate = returnDate;
    }
    /**
     * @return true if the tape has not been returned, false otherwise
     */
    public boolean notReturned() { return this.returnDate == null; }
}