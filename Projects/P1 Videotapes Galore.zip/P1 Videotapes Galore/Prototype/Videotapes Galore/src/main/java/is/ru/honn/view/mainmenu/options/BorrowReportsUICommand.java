/*
 * @(#)BorrowReportsUICommand.java 1.0 26 Sep 2018 Edda Steinunn Rúnarsdóttir
 *
 * Copyright (c) Edda Steinunn Rúnarsdóttir
 */
package is.ru.honn.view.mainmenu.options;

import is.ru.honn.factory.BorrowServiceFactory;
import is.ru.honn.service.BorrowService;
import is.ru.honn.view.mainmenu.options.submenu.BorrowReportsMainMenuUI;
import is.ru.honn.view.MenuCommand;

import java.util.Scanner;

/**
 * Class BorrowReportsUICommand (BorrowReportsUICommand.java)
 * Prompts user for input to output various reports on borrow records
 *
 * @author Edda Steinunn Rúnarsdóttir
 * @version 1.0, 26 Sep 2018
 */
public class BorrowReportsUICommand implements MenuCommand
{
    /**
     * Borrow service to manipulate borrow records in system
     */
    private BorrowService borrowService;
    /**
     * Scanner to use for system input
     */
    private Scanner scanner;

    /**
     * Gets borrow service to manipulate borrow record list
     */
    public BorrowReportsUICommand(Scanner scanner)
    {
        this.scanner = scanner;
        borrowService = BorrowServiceFactory.getBorrowService();
    }

    /**
     * Gets borrow service to manipulate borrow record list
     */
    public BorrowReportsUICommand()
    {
        this.scanner = new Scanner(System.in);
        borrowService = BorrowServiceFactory.getBorrowService();
    }
    /**
     * @return name of this command to display in main mainmenu
     */
    public String getCommandName()
    {
        return "View Report on Borrows Registered";
    }
    /**
     * Prompts user for friend information on new friend
     * Then adds that new friend to system via friend service
     */
    public void executeCommand()
    {
        BorrowReportsMainMenuUI borrowReportsProgram = new BorrowReportsMainMenuUI(this.scanner);
        borrowReportsProgram.start();
    }
}
