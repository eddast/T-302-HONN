/*
 * @(#)BorrowException.java 1.0 26 Sep 2018 Edda Steinunn Rúnarsdóttir
 *
 * Copyright (c) Edda Steinunn Rúnarsdóttir
 */
package is.ru.honn.service;

/**
 * Class BorrowException (BorrowException.java)
 * Runtime Exception thrown in BorrowService.java when borrowing of tape is unsuccessful
 *
 * @author Edda Steinunn Rúnarsdóttir
 * @version 1.0, 26 Sep 2018
 */
public class BorrowException extends RuntimeException
{
    public BorrowException(String message)
    {
        super(message);
    }
}
