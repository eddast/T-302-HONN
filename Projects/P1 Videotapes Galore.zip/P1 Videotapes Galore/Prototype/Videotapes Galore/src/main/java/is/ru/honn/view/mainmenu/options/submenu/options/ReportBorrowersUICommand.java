/*
 * @(#)ReportBorrowersUICommand.java 1.0 26 Sep 2018 Edda Steinunn Rúnarsdóttir
 *
 * Copyright (c) Edda Steinunn Rúnarsdóttir
 */
package is.ru.honn.view.mainmenu.options.submenu.options;

import is.ru.honn.factory.BorrowServiceFactory;
import is.ru.honn.factory.ScannerFactory;
import is.ru.honn.model.Borrower;
import is.ru.honn.model.ValidationResponse;
import is.ru.honn.service.BorrowService;
import is.ru.honn.service.ConversionService;
import is.ru.honn.view.MenuCommand;

import java.util.Date;
import java.util.List;
import java.util.Scanner;

/**
 * Class ReportBorrowersUICommand (ReportBorrowersUICommand.java)
 * Outputs a list of all friends borrowing tapes (along with which tapes they're borrowing)
 *
 * @author Edda Steinunn Rúnarsdóttir
 * @version 1.0, 26 Sep 2018
 */
public class ReportBorrowersUICommand implements MenuCommand
{
    /**
     * Borrow service to manipulate borrow records in system
     */
    private BorrowService borrowService;
    /**
     * Scanner to use for system input
     */
    private Scanner scanner;

    /**
     * Gets borrow service to manipulate borrow record list
     */
    public ReportBorrowersUICommand(Scanner scanner)
    {
        this.scanner = scanner;
        borrowService = BorrowServiceFactory.getBorrowService();
    }
    /**
     * Gets borrow service to manipulate borrow record list
     */
    public ReportBorrowersUICommand()
    {
        scanner = new Scanner(System.in);
        borrowService = BorrowServiceFactory.getBorrowService();
    }
    /**
     * @return name of this command to display in main mainmenu
     */
    public String getCommandName()
    {
        return "Output list of Friends Borrowing Tapes";
    }
    /**
     * Outputs list of all friends borrowing tapes (along with tapes they're borrowing)
     */
    public void executeCommand()
    {
        String inputDate = "";
        Scanner scanner = ScannerFactory.getInputScanner();

        System.out.println("ENTER A DATE TO LOOK UP BORROWERS FOR GIVEN DATE AND PRESS ENTER:\n");
        System.out.println("Date: ");       inputDate = scanner.nextLine();

        Date lookupDate = ConversionService.stringToDate(inputDate);
        ValidationResponse borrowerReportValidation = borrowerReportValid(lookupDate);
        if (borrowerReportValidation.modelIsValid())
        {
           List<Borrower> borrowers = borrowService.getBorrowers(lookupDate);
           if(borrowers.size() == 0)
           {
               System.out.println("== NO FRIENDS CURRENTLY BORROWING ANY TAPES FOR GIVEN DATE == ");
               return;
           }
           for(int i = 0; i < borrowers.size(); i++)
           {
               System.out.println(i+1 + ".");
               System.out.println(borrowers.get(i));
           }
           return;
        }
        /* error message if date could not be parsed */
        System.out.println("\nERROR: report can not be created.");
        System.out.println(borrowerReportValidation.getErrorMsg());
    }

    private ValidationResponse borrowerReportValid(Date lookupDate)
    {
        ValidationResponse validationResult = new ValidationResponse();
        if (lookupDate == null)
        {
            validationResult.setModelValidation(false);
            validationResult.addError("Input must be a valid date");
        }
        return validationResult;
    }
}
