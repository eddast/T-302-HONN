/*
 * @(#)VideotapesGaloreMainMenuUI.java 1.0 26 Sep 2018 Edda Steinunn Rúnarsdóttir
 *
 * Copyright (c) Edda Steinunn Rúnarsdóttir
 */
package is.ru.honn.view.mainmenu.options.submenu;

import is.ru.honn.view.MenuCommand;
import is.ru.honn.view.AbstractMainMenuUI;
import is.ru.honn.view.mainmenu.options.submenu.options.ReportBorrowersOverMonthUICommand;
import is.ru.honn.view.mainmenu.options.submenu.options.ReportBorrowersUICommand;
import is.ru.honn.view.mainmenu.options.submenu.options.ReportTapesUICommand;

import java.util.Scanner;

/**
 * Class VideotapesGaloreMainMenuUI (VideotapesGaloreMainMenuUI.java)
 * Interacts with and provides instructions to system users of VIDEOTAPES GALORE system
 * Decides which functionality/actions to execute by receiving user input
 *
 * @author Edda Steinunn Rúnarsdóttir
 * @version 1.0, 26 Sep 2018
 */
public class BorrowReportsMainMenuUI extends AbstractMainMenuUI
{
    /**
     * Set up options available for videotapes galore system
     * Set up custom scanner
     */
    public BorrowReportsMainMenuUI(Scanner scanner)
    {
        this.scanner = scanner;
        this.commandsAvailable = new MenuCommand[] {
                new ReportTapesUICommand(scanner),
                new ReportBorrowersUICommand(scanner),
                new ReportBorrowersOverMonthUICommand(scanner),
        };
    }
    /**
     * Set up options available for videotapes galore system
     */
    public BorrowReportsMainMenuUI()
    {
        this.scanner = new Scanner(System.in);
        this.commandsAvailable = new MenuCommand[] {
                new ReportTapesUICommand(),
                new ReportBorrowersUICommand(),
                new ReportBorrowersOverMonthUICommand(),
        };
    }

    /**
     * No welcome message needed for output report
     */
    public void printWelcomeMessage()
    {
        System.out.println("\n=============================\n");
        System.out.println("  OUTPUT BORROW REPORTS MENU");
        System.out.println("\n=============================\n");
    }
    /**
     * Prints message explicitly indicating user he has quit borrows report mainmenu
     */
    public void printQuitMessage()
    {
        System.out.println("Returning to main menu");
    }
    /**
     * @return on quit option
     */
    public String getQuitOption()
    {
        return "Back To Main Menu";
    }
}
