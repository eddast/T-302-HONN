/*
 * @(#)DataParser.java 1.0 26 Sep 2018 Edda Steinunn Rúnarsdóttir
 *
 * Copyright (c) Edda Steinunn Rúnarsdóttir
 */
package is.ru.honn.parser;

/**
 * Interface DataParser (DataReader.java)
 * Reads in JSON data files on friends and tapes and adds them to system
 *
 * @author Edda Steinunn Rúnarsdóttir
 * @version 1.0, 26 Sep 2018
 */
public interface DataParser
{
    /**
     * Initialise all data for system
     */
    void initializeSystem();
    /**
     * Reads in friends from JSON data file and adds them to system
     */
    void parseFriends();
    /**
     * Reads in video tapes from JSON data file and adds them to system
     */
    void parseTapes();
}
