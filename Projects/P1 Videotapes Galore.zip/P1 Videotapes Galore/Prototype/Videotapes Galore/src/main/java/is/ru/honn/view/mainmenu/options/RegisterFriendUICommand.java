/*
 * @(#)RegisterFriendUICommand.java 1.0 26 Sep 2018 Edda Steinunn Rúnarsdóttir
 *
 * Copyright (c) Edda Steinunn Rúnarsdóttir
 */
package is.ru.honn.view.mainmenu.options;

import is.ru.honn.factory.FriendServiceFactory;
import is.ru.honn.model.ValidationResponse;
import is.ru.honn.service.FriendService;
import is.ru.honn.view.MenuCommand;

import java.util.Scanner;

/**
 * Class RegisterFriendUICommand (RegisterFriendUICommand.java)
 * Prompts user for input to add new friend to system
 *
 * @author Edda Steinunn Rúnarsdóttir
 * @version 1.0, 26 Sep 2018
 */
public class RegisterFriendUICommand implements MenuCommand
{
    /**
     * Friend service to manipulate friends in system
     */
    private FriendService friendService;
    /**
     * Scanner to read input from
     */
    private Scanner scanner;

    /**
     * Gets friend service to manipulate friend list
     * Gets custom scanner to use
     */
    public RegisterFriendUICommand(Scanner scanner)
    {
        this.scanner = scanner;
        friendService = FriendServiceFactory.getFriendService();
    }
    /**
     * Gets friend service to manipulate friend list
     */
    public RegisterFriendUICommand()
    {
        this.scanner = new Scanner(System.in);
        friendService = FriendServiceFactory.getFriendService();
    }
    /**
     * @return name of this command to display in main mainmenu
     */
    public String getCommandName()
    {
        return "Register New Friend";
    }
    /**
     * Prompts user for friend information on new friend
     * Then adds that new friend to system via friend service
     */
    public void executeCommand()
    {
        String name = "", address = "", email = "", telephone = "";

        /* prompt user for input on new friend */
        System.out.println("ENTER THE FOLLOWING INFORMATION ON NEW FRIEND AND PRESS ENTER:\n");
        System.out.print("Name: ");         name = scanner.nextLine();
        System.out.print("Address: ");      address = scanner.nextLine();
        System.out.print("E-mail: ");       email = scanner.nextLine();
        System.out.print("Telephone: ");    telephone = scanner.nextLine();

        /* validate format of user input */
        ValidationResponse friendInputValidation = friendInputValid(name, address, email, telephone);

        if(friendInputValidation.modelIsValid())
        {
            friendService.registerFriend(name, address, email, telephone);

            /* feedback on success */
            System.out.println("\nNEW FRIEND WAS SUCCESSFULLY REGISTERED!");
            return;
        }

        /* error message if friend could not be registered */
        System.out.println("\nERROR: friend could not be registered.");
        System.out.println(friendInputValidation.getErrorMsg());
    }
    /**
     * Determines whether user inputted friend in correct format
     *
     * @param name
     * @param address
     * @param email
     * @param telephone
     * @return ValidationResponse with boolean validation for friend model and error msg if appropriate
     */
    private ValidationResponse friendInputValid(String name, String address, String email, String telephone)
    {
        ValidationResponse validationResult = new ValidationResponse();

        /* name must be provided */
        if(name.equals(""))
        {
            validationResult.setModelValidation(false);
            validationResult.addError("Name must be provided for friend");
        }
        /* address must be provided */
        if(address.equals(""))
        {
            validationResult.setModelValidation(false);
            validationResult.addError("Address must be provided for friend");
        }
        /* email must be provided */
        if(email.equals(""))
        {
            validationResult.setModelValidation(false);
            validationResult.addError("Email address must be added for friend");
        }
        /* telephone must be provided */
        if(telephone.equals(""))
        {
            validationResult.setModelValidation(false);
            validationResult.addError("Telephone number must be added for friend");
        }

        return validationResult;
    }
}
