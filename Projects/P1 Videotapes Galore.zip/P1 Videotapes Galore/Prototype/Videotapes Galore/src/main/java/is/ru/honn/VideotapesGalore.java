/*
 * @(#)VideotapesGalore.java 1.0 26 Sep 2018 Edda Steinunn Rúnarsdóttir
 *
 * Copyright (c) Edda Steinunn Rúnarsdóttir
 */
package is.ru.honn;

import is.ru.honn.parser.BorrowDataParser;
import is.ru.honn.view.mainmenu.VideotapesGaloreMainMenuUI;


/**
 * Application VideotapesGalore (VideotapesGalore.java)
 * Small in-memory tape borrowing management system for registered friends and tapes
 * Initializes system and starts up program UI
 *
 * @author Edda Steinunn Rúnarsdóttir
 * @version 1.0, 26 Sep 2018
 */
public class VideotapesGalore
{
    public static void main(String[] args)
    {
        /* set up data for system */
        BorrowDataParser initializer = new BorrowDataParser();
        initializer.initializeSystem();

        /* start program UI */
        VideotapesGaloreMainMenuUI programUI = new VideotapesGaloreMainMenuUI();
        programUI.start();
    }
}
