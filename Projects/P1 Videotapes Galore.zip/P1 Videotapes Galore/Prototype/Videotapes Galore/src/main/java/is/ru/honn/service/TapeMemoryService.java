/*
 * @(#)TapeMemoryService.java 1.0 26 Sep 2018 Edda Steinunn Rúnarsdóttir
 *
 * Copyright (c) Edda Steinunn Rúnarsdóttir
 */
package is.ru.honn.service;

import is.ru.honn.model.Tape;

import java.util.ArrayList;
import java.util.Date;
import java.util.List;

/**
 * Class TapeMemoryService (TapeMemoryService.java)
 * Contains and defines read/modify actions for list of tapes in system
 *
 * @author Edda Steinunn Rúnarsdóttir
 * @version 1.0, 26 Sep 2018
 */
public class TapeMemoryService implements TapeService
{
    /**
     * Tapes in system
     */
    private List<Tape> tapes;


    /**
     * Initializes tape list
     */
    public TapeMemoryService()
    {
        tapes = new ArrayList<Tape>();
    }
    /**
     * Registers new tape to system with predefined id
     *
     * @param id
     * @param title
     * @param director
     * @param type
     * @param releaseDate
     * @param EIDR
     */
    public void registerTape(int id, String title, String director, String type, Date releaseDate, String EIDR)
    {
        Tape tape = new Tape(id, title, director, type, releaseDate, EIDR);
        tapes.add(tape);
    }
    /**
     * Registers new tape to system, assigns id to tape
     *
     * @param title
     * @param director
     * @param type
     * @param releaseDate
     * @param EIDR
     */
    public void registerTape(String title, String director, String type, Date releaseDate, String EIDR)
    {
        Tape tape = new Tape(tapes.size()+1, title, director, type, releaseDate, EIDR);
        tapes.add(tape);
    }
    /**
     * Gets specific tape
     *
     * @param id id number of tape to get
     * @return tape by id
     * @throws ResourceNotFoundException if tape is not found
     */
    public Tape getTapeById(int id) throws ResourceNotFoundException
    {
        for(int i = 0; i < this.tapes.size(); i++)
        {
            Tape tape = this.tapes.get(i);
            if(tape.getId() == id)
            {
                return tape;
            }
        }

        throw new ResourceNotFoundException("Tape with id " + id + " not found");
    }
}
