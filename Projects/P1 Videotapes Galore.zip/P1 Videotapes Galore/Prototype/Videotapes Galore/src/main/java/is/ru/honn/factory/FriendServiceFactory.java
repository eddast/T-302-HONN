/*
 * @(#)FriendServiceFactory.java 1.0 26 Sep 2018 Edda Steinunn Rúnarsdóttir
 *
 * Copyright (c) Edda Steinunn Rúnarsdóttir
 */
package is.ru.honn.factory;

import is.ru.honn.service.FriendMemoryService;
import is.ru.honn.service.FriendService;

/**
 * Class FriendServiceFactory (FriendServiceFactory.java)
 * Gets static instance of friend service for classes to use
 *
 * @author Edda Steinunn Rúnarsdóttir
 * @version 1.0, 26 Sep 2018
 */
public class FriendServiceFactory
{
    /**
     * Static instance of friend service
     */
    private static FriendService friendService = null;


    /**
     * Gets friend service for classes to use
     *
     * @return friend service
     */
    public static FriendService getFriendService()
    {
        if(friendService == null)
        {
            Class c = BorrowProperties.getClassFromProperty("friend");
            try
            {
                friendService = (FriendService) c.newInstance();
            }
            catch (InstantiationException e)
            {
                e.printStackTrace();
            }
            catch (IllegalAccessException e)
            {
                e.printStackTrace();
            }
        }
        return friendService;
    }
}
