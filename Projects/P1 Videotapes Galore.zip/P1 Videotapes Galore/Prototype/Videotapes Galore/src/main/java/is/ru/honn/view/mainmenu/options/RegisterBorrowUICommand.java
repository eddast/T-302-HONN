/*
 * @(#)RegisterBorrowUICommand.java 1.0 26 Sep 2018 Edda Steinunn Rúnarsdóttir
 *
 * Copyright (c) Edda Steinunn Rúnarsdóttir
 */
package is.ru.honn.view.mainmenu.options;

import is.ru.honn.factory.BorrowServiceFactory;
import is.ru.honn.factory.FriendServiceFactory;
import is.ru.honn.factory.TapeServiceFactory;
import is.ru.honn.model.ValidationResponse;
import is.ru.honn.service.*;
import is.ru.honn.view.MenuCommand;

import java.util.Date;
import java.util.Scanner;

/**
 * Class RegisterBorrowUICommand (RegisterBorrowUICommand.java)
 * Prompts user for input to add new borrow record to system
 *
 * @author Edda Steinunn Rúnarsdóttir
 * @version 1.0, 26 Sep 2018
 */
public class RegisterBorrowUICommand implements MenuCommand
{
    /**
     * Borrow service to manipulate borrow records in system
     */
    private BorrowService borrowService;
    /**
     * Friend service to manipulate friends in system
     */
    private FriendService friendService;
    /**
     * Tape service to manipulate tapes in system
     */
    private TapeService tapeService;
    /**
     * Scanner to use for system input
     */
    private Scanner scanner;

    /**
     * Gets borrow service to manipulate borrow record list
     */
    public RegisterBorrowUICommand(Scanner scanner)
    {
        this.scanner = scanner;
        borrowService = BorrowServiceFactory.getBorrowService();
        friendService = FriendServiceFactory.getFriendService();
        tapeService = TapeServiceFactory.getTapeService();
    }

    /**
     * Gets borrow service to manipulate borrow record list
     */
    public RegisterBorrowUICommand()
    {
        scanner = new Scanner(System.in);
        borrowService = BorrowServiceFactory.getBorrowService();
        friendService = FriendServiceFactory.getFriendService();
        tapeService = TapeServiceFactory.getTapeService();
    }
    /**
     * @return name of this command to display in main mainmenu
     */
    public String getCommandName()
    {
        return "Lend A Tape to A Friend";
    }
    /**
     * Prompts user for friend information on new friend
     * Then adds that new friend to system via friend service
     */
    public void executeCommand()
    {
        String borrowerIdStr, tapeIdStr, borrowDateStr = "";

        /* prompt user for input on new tape */
        System.out.println("ENTER THE FOLLOWING INFORMATION AND PRESS ENTER:\n");
        System.out.print("Friend ID: ");                    borrowerIdStr = scanner.nextLine();
        System.out.print("Tape ID: ");                      tapeIdStr = scanner.nextLine();
        System.out.print("Date of borrow (YYYY-MM-DD): ");  borrowDateStr = scanner.nextLine();

        /* set values in correct form */
        int borrowerId = ConversionService.idToInt(borrowerIdStr);
        int tapeId = ConversionService.idToInt(tapeIdStr);
        Date borrowDate = ConversionService.stringToDate(borrowDateStr);

        /* validate format of user input */
        ValidationResponse borrowInputValidation = borrowInputValid(borrowerId, tapeId, borrowDate);

        if(borrowInputValidation.modelIsValid())
        {
            /* attempt to register borrow */
            try
            {
                borrowService.registerBorrow(borrowerId, tapeId, borrowDate);
            }
            /* raise error on borrow exception when borrow cannot be registered */
            catch (BorrowException e)
            {
                borrowInputValidation.setModelValidation(false);
                borrowInputValidation.addError(e.getMessage());
            }
            /* feedback on success */
            if(borrowInputValidation.modelIsValid())
            {
                System.out.println("\nNEW BORROW RECORD WAS SUCCESSFULLY REGISTERED!");
                return;
            }
        }
        /* error message if borrow could not be registered */
        System.out.println("\nERROR: tape could not be borrowed to friend.");
        System.out.println(borrowInputValidation.getErrorMsg());
    }
    /**
     *  Checks if user input for borrow record is valid
     *
     * @param borrowerId
     * @param tapeId
     * @param borrowDate
     * @return ValidationResponse with boolean validation for borrow record model and error msg if appropriate
     */
    private ValidationResponse borrowInputValid(int borrowerId, int tapeId, Date borrowDate)
    {
        ValidationResponse validationResult = new ValidationResponse();

        /* borrower id must be provided and an integer (i.e. not -1 for error) */
        if(borrowerId == -1)
        {
            validationResult.setModelValidation(false);
            validationResult.addError("Friend ID is not a valid number");
        }
        /* tape id must be provided and an integer (i.e. not -1 for error) */
        if(tapeId == -1)
        {
            validationResult.setModelValidation(false);
            validationResult.addError("Tape ID is not a valid number");
        }
        /* borrow date must be a valid YYYY-DD-MM formatted date */
        if(borrowDate == null)
        {
            validationResult.setModelValidation(false);
            validationResult.addError("Date of borrow not correctly set (must be in YYYY-MM-DD format)");
        }

        return validationResult;
    }
}
