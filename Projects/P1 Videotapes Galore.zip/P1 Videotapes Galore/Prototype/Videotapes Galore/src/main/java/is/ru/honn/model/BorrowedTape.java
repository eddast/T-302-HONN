/*
 * @(#)BorrowedTape.java 1.0 26 Sep 2018 Edda Steinunn Rúnarsdóttir
 *
 * Copyright (c) Edda Steinunn Rúnarsdóttir
 */
package is.ru.honn.model;

import java.util.Date;

/**
 * Class BorrowedTape (BorrowedTape.java)
 * Data type representing minimal information on borrowed tape
 * i.e. tape id, title and date of borrow
 *
 * @author Edda Steinunn Rúnarsdóttir
 * @version 1.0, 26 Sep 2018
 */
public class BorrowedTape
{
    /**
     * Tape id
     */
    private int id;
    /**
     * Title of tape
     */
    private String title;
    /**
     * Date when tape was borrowed
     */
    private Date borrowDate;


    /**
     * Constructs a tape data type
     * @param id id of tape
     * @param title title of tape
     * @param borrowDate date when tape was borrowed
     */
    public BorrowedTape(int id, String title, Date borrowDate)
    {
        this.id = id;
        this.title = title;
        this.borrowDate = borrowDate;
    }
    /**
     * @return id of tape
     */
    public int getId()
    {
        return id;
    }
    /**
     * @return tape title
     */
    public String getTitle()
    {
        return title;
    }
    /**
     * @return tape title
     */
    public Date getBorrowDate()
    {
        return borrowDate;
    }

}
