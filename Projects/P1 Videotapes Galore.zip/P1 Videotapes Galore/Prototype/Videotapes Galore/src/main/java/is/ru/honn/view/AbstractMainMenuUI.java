/*
 * @(#)AbstractMainMenuUI.java 1.0 26 Sep 2018 Edda Steinunn Rúnarsdóttir
 *
 * Copyright (c) Edda Steinunn Rúnarsdóttir
 */
package is.ru.honn.view;

import is.ru.honn.factory.ScannerFactory;

import java.util.Scanner;

/**
 * Class AbstractMainMenuUI (AbstractMainMenuUI.java)
 * Implements generic main-mainmenu based functionality for a main-mainmenu system
 *
 * @author Edda Steinunn Rúnarsdóttir
 * @version 1.0, 26 Sep 2018
 */
public abstract class AbstractMainMenuUI implements MainMenuUI
{
    /**
     * Scanner to use for system input
     */
    protected Scanner scanner;
    /**
     * loops main mainmenu for user input and executes user requested options
     */
    public void start()
    {
        printWelcomeMessage();
        String command = "";
        while(true)
        {
            System.out.print("\n\t-----\n");
            printMainMenu();
            System.out.print("\nENTER COMMAND: ");
            command = scanner.nextLine();
            System.out.print("\n\t-----\n\n");

            if (!commandIsValid(command))
            {
                printCommandInvalidError();
            }
            else
            {
                int commandId = Integer.parseInt(command) - 1;
                if(wantsToQuit(commandId))
                {
                    break;
                }
                else
                {
                    executeCommand(Integer.parseInt(command) - 1);
                }
            }
        }
        printQuitMessage();
    }
    /**
     * Prints all options available in system in a list
     */
    public void printMainMenu()
    {
        System.out.println("\nCHOOSE COMMAND AND PRESS ENTER\n");
        for(int i = 0; i < commandsAvailable.length; i++)
        {
            System.out.println("\t" + (i+1) + ". " + commandsAvailable[i].getCommandName());
        }
        System.out.println("\t" + (commandsAvailable.length+1) + ". " + getQuitOption());
    }
    /**
     * Prints error if command is invalid
     */
    public void printCommandInvalidError()
    {
        System.out.println("INVALID OPTION INPUTTED");
        System.out.println("choose option 1-" + (commandsAvailable.length+1));
    }
    /**
     * @param input user input for main mainmenu
     * @return true if command is valid, false otherwise
     */
    public boolean commandIsValid(String input)
    {
        int command = 0;
        try
        {
            command = Integer.parseInt(input);
        }
        catch (NumberFormatException e)
        {
            return false;
        }
        return command <= commandsAvailable.length+1;
    }
    /**
     * Executes user inputted command
     *
     * @param command number of command to execute
     */
    public void executeCommand(int command)
    {
        commandsAvailable[command].executeCommand();
    }
    /**
     * @param input user input
     * @return true if user has typed 'quit' to quit system, false otherwise
     */
    public boolean wantsToQuit(int input)
    {
        return input == commandsAvailable.length;
    }


    /**
     * Available options in system (system-specific)
     */
    public MenuCommand[] commandsAvailable;
    /**
     * Prints quit mainmenu indication (system-specific)
     */
    public abstract String getQuitOption();
    /**
     * Prints welcome message to user (system-specific)
     */
    public abstract void printWelcomeMessage();
    /**
     * Prints quit message to user (system-specific)
     */
    public abstract void printQuitMessage();
}
