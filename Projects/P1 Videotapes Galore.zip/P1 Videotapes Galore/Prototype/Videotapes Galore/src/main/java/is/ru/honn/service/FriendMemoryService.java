/*
 * @(#)FriendMemoryService.java 1.0 26 Sep 2018 Edda Steinunn Rúnarsdóttir
 *
 * Copyright (c) Edda Steinunn Rúnarsdóttir
 */
package is.ru.honn.service;

import is.ru.honn.model.Friend;

import java.util.ArrayList;
import java.util.List;

/**
 * Class FriendMemoryService (FriendMemoryService.java)
 * Contains and defines read/modify actions for list of friends in system
 *
 * @author Edda Steinunn Rúnarsdóttir
 * @version 1.0, 26 Sep 2018
 */
public class FriendMemoryService implements FriendService
{
    /**
     * Friends in system
     */
    private List<Friend> friends;


    /**
     * Constructs friend memory service
     */
    public FriendMemoryService()
    {
        friends = new ArrayList<Friend>();
    }
    /**
     * Registers new friend to system by name, addr, email and tel with predefined id
     *
     * @param name
     * @param address
     * @param email
     * @param telephone
     */
    public void registerFriend(int id, String name, String address, String email, String telephone)
    {
        Friend friend = new Friend(id, name, address, email, telephone);
        this.friends.add(friend);
    }
    /**
     * Registers new friend to system by name, addr, email and tel, assigns id
     *
     * @param name
     * @param address
     * @param email
     * @param telephone
     */
    public void registerFriend(String name, String address, String email, String telephone)
    {
        Friend friend = new Friend(friends.size()+1, name, address, email, telephone);
        this.friends.add(friend);
    }
    /**
     * Get specific friend from system
     *
     * @param id id of friend to get
     * @return the friend by id
     * @throws ResourceNotFoundException if no friend is found by id
     */
    public Friend getFriendById(int id) throws ResourceNotFoundException
    {
        for(int i = 0; i < this.friends.size(); i++)
        {
            Friend friend = this.friends.get(i);
            if(friend.getId() == id)
            {
                return friend;
            }
        }

        throw new ResourceNotFoundException("Friend with id " + id + " not found");
    }
}
