/*
 * @(#)RegisterTapeUICommand.java 1.0 26 Sep 2018 Edda Steinunn Rúnarsdóttir
 *
 * Copyright (c) Edda Steinunn Rúnarsdóttir
 */
package is.ru.honn.view.mainmenu.options;

import is.ru.honn.factory.TapeServiceFactory;
import is.ru.honn.model.ValidationResponse;
import is.ru.honn.service.ConversionService;
import is.ru.honn.service.TapeService;
import is.ru.honn.view.MenuCommand;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Scanner;

/**
 * Class RegisterTapeUICommand (RegisterTapeUICommand.java)
 * Prompts user for input to add new tape to system
 *
 * @author Edda Steinunn Rúnarsdóttir
 * @version 1.0, 26 Sep 2018
 */
public class RegisterTapeUICommand implements MenuCommand
{
    /**
     * Tape service to manipulate tapes in system
     */
    private TapeService tapeService;

    /**
     * Scanner to use for system input
     */
    private Scanner scanner;

    /**
     * Initiates new tape service
     * Sets a custom scanner receieved through constructor
     */
    public RegisterTapeUICommand(Scanner scanner)
    {
        this.scanner = scanner;
        tapeService = TapeServiceFactory.getTapeService();
    }

    /**
     * Initiates new tape service
     */
    public RegisterTapeUICommand()
    {
        scanner = new Scanner(System.in);
        tapeService = TapeServiceFactory.getTapeService();
    }
    /**
     * @return name of this command to display in main mainmenu
     */
    public String getCommandName()
    {
        return "Register New Video Tape";
    }
    /**
     * Prompts user for tape information to get on new tape
     * Then adds the tape to system via tape service
     */
    public void executeCommand()
    {
        String title = "", director = "", type = "", releaseDateStr = "", EIDR = "";

        /* prompt user for input on new tape */
        System.out.println("ENTER FOLLOWING INFORMATION ON NEW VIDEO TAPE THEN PRESS ENTER:\n");
        System.out.print("Title: ");                        title = scanner.nextLine();
        System.out.print("Director: ");                     director = scanner.nextLine();
        System.out.print("Type (VHS/Betamax): ");           type = scanner.nextLine();
        System.out.print("Release Date (YYYY-MM-DD): ");    releaseDateStr = scanner.nextLine();
        System.out.print("EIDR Number: ");                  EIDR = scanner.nextLine();

        /* set values in correct form */
        Date releaseDate = ConversionService.stringToDate(releaseDateStr);

        /* validate format of user input */
        ValidationResponse tapeValidation = videotapeValid(title, director, type, releaseDate, EIDR);

        if(tapeValidation.modelIsValid())
        {
            tapeService.registerTape(title, director, type, releaseDate, EIDR);

            /* feedback on success */
            System.out.println("\nNEW VIDEO TAPE WAS SUCCESSFULLY REGISTERED!");
            return;
        }

        /* error message if tape could not be registered */
        System.out.println("\nERROR: video tape could not be registered.");
        System.out.println(tapeValidation.getErrorMsg());
    }
    /**
     * Determines whether user input is valid
     *
     * @param title user inputted video tape title
     * @param director user inputted video tape director
     * @param type user inputted video tape type
     * @param EIDR user inputted EIDR number
     * @return ValidationResponse with boolean validation for tape model and error msg if appropriate
     */
    private ValidationResponse videotapeValid(String title, String director, String type, Date releaseDate, String EIDR)
    {
        ValidationResponse validationResult = new ValidationResponse();

        /* title must be provided */
        if(title.equals(""))
        {
            validationResult.setModelValidation(false);
            validationResult.addError("Title must be provided for video tape");
        }
        /* director must be provided */
        if(director.equals(""))
        {
            validationResult.setModelValidation(false);
            validationResult.addError("Director must be provided for video tape");
        }
        /* type must be provided and be either vhs or betamax */
        if(!(type.toLowerCase().equals("vhs") || type.toLowerCase().equals("betamax")))
        {
            validationResult.setModelValidation(false);
            validationResult.addError("Invalid type provided for video tape (must be either 'VHS' or 'Betamax')");
        }
        /* type must be provided and be either vhs or betamax */
        if(releaseDate == null)
        {
            validationResult.setModelValidation(false);
            validationResult.addError("Date of release not correctly set (must be in YYYY-MM-DD format)");
        }
        /* type must be provided and be either vhs or betamax */
        if(EIDR.equals(""))
        {
            validationResult.setModelValidation(false);
            validationResult.addError("EIDR number must be provided for video tape");
        }

        return validationResult;
    }
}
