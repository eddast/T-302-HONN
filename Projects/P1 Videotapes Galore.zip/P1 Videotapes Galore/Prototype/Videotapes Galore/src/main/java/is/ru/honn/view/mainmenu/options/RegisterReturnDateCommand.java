package is.ru.honn.view.mainmenu.options;

import is.ru.honn.factory.BorrowServiceFactory;
import is.ru.honn.factory.FriendServiceFactory;
import is.ru.honn.model.ValidationResponse;
import is.ru.honn.service.BorrowException;
import is.ru.honn.service.BorrowService;
import is.ru.honn.service.ConversionService;
import is.ru.honn.service.FriendService;
import is.ru.honn.view.MenuCommand;

import java.util.Date;
import java.util.Scanner;

public class RegisterReturnDateCommand implements MenuCommand {

    /**
     * Friend service to manipulate friends in system
     */
    private BorrowService borrowService;
    /**
     * Scanner to read input from
     */
    private Scanner scanner;

    /**
     * Gets friend service to manipulate friend list
     * Gets custom scanner to use
     */
    public RegisterReturnDateCommand(Scanner scanner)
    {
        this.scanner = scanner;
        borrowService = BorrowServiceFactory.getBorrowService();
    }
    /**
     * Gets friend service to manipulate friend list
     */
    public RegisterReturnDateCommand()
    {
        this.scanner = new Scanner(System.in);
        borrowService = BorrowServiceFactory.getBorrowService();
    }
    /**
     * @return name of this command to display in main mainmenu
     */
    public String getCommandName()
    {
        return "Return a Tape";
    }
    /**
     * Prompts user for friend information on new friend
     * Then adds that new friend to system via friend service
     */
    public void executeCommand()
    {
        String borrowerIdStr = "", tapeIdStr = "", returnDateStr = "";

        /* prompt user for input on new friend */
        System.out.println("ENTER THE FOLLOWING INFORMATION TO RETURN TAPE AND PRESS ENTER:\n");
        System.out.print("borrowerId: ");                   borrowerIdStr = scanner.nextLine();
        System.out.print("tapeId: ");                       tapeIdStr = scanner.nextLine();
        System.out.print("Return date (yyyy-MM-dd): ");     returnDateStr = scanner.nextLine();

        /* validate format of user input */
        ValidationResponse friendInputValidation = returnDateInputValid(borrowerIdStr, tapeIdStr, returnDateStr);

        if(friendInputValidation.modelIsValid())
        {
            int borrowerId = ConversionService.idToInt(borrowerIdStr);
            int tapeId = ConversionService.idToInt(tapeIdStr);
            Date returnDate = ConversionService.stringToDate(returnDateStr);
            try
            {
                borrowService.returnTape(borrowerId, tapeId, returnDate);
                /* feedback on success */
                System.out.println("\nRETURN DATE WAS SUCCESSFULLY REGISTERED");
            }
            catch (BorrowException e)
            {
                System.out.println(e.getMessage());
            }

            return;
        }

        /* error message if friend could not be registered */
        System.out.println("\nERROR: friend could not be registered.");
        System.out.println(friendInputValidation.getErrorMsg());
    }
    /**
     * Determines whether user inputted friend in correct format
     *
     * @param
     * @return ValidationResponse with boolean validation for friend model and error msg if appropriate
     */
    private ValidationResponse returnDateInputValid(String borrowerIdStr, String tapeIdStr, String returndateStr)
    {
        ValidationResponse validationResult = new ValidationResponse();

        int borrowerId = ConversionService.idToInt(borrowerIdStr);
        if (borrowerId == - 1)
        {
            validationResult.setModelValidation(false);
            validationResult.addError("borrowerId has to be a number");
        }
        int tapeId = ConversionService.idToInt(tapeIdStr);
        if (tapeId == -1)
        {
            validationResult.setModelValidation(false);
            validationResult.addError("tapeId has to be a number");
        }
        Date returnDate = ConversionService.stringToDate(returndateStr);
        if (returnDate == null)
        {
            validationResult.setModelValidation(false);
            validationResult.addError("Return date is not a valid date (yyyy-MM-dd)");
        }

        return validationResult;
    }
}
