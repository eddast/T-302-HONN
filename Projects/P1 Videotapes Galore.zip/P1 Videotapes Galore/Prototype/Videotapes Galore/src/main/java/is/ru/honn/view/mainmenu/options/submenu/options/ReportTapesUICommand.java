/*
 * @(#)ReportTapesUICommand.java 1.0 26 Sep 2018 Edda Steinunn Rúnarsdóttir
 *
 * Copyright (c) Edda Steinunn Rúnarsdóttir
 */
package is.ru.honn.view.mainmenu.options.submenu.options;

import is.ru.honn.factory.BorrowServiceFactory;
import is.ru.honn.factory.ScannerFactory;
import is.ru.honn.model.BorrowedTapeDetails;
import is.ru.honn.model.ValidationResponse;
import is.ru.honn.service.BorrowService;
import is.ru.honn.service.ConversionService;
import is.ru.honn.view.MenuCommand;

import java.util.Date;
import java.util.List;
import java.util.Scanner;

/**
 * Class ReportTapesUICommand (ReportTapesUICommand.java)
 * Outputs list of borrowed tapes (along with borrowers) for user
 *
 * @author Edda Steinunn Rúnarsdóttir
 * @version 1.0, 26 Sep 2018
 */
public class ReportTapesUICommand implements MenuCommand
{
    /**
     * Borrow service to manipulate borrow records in system
     */
    private BorrowService borrowService;
    /**
     * Scanner to use for system input
     */
    private Scanner scanner;

    /**
     * Gets borrow service to manipulate borrow record list
     */
    public ReportTapesUICommand(Scanner scanner)
    {
        this.scanner = scanner;
        borrowService = BorrowServiceFactory.getBorrowService();
    }
    /**
     * Gets borrow service to manipulate borrow record list
     */
    public ReportTapesUICommand()
    {
        scanner = new Scanner(System.in);
        borrowService = BorrowServiceFactory.getBorrowService();
    }
    /**
     * @return name of this command to display in main mainmenu
     */
    public String getCommandName()
    {
        return "Output list of Tapes On Loan";
    }
    /**
     * Outputs list of borrowed tapes (along with with their borrower)
     */
    public void executeCommand()
    {
        String inputDate = "";
        Scanner scanner = ScannerFactory.getInputScanner();

        System.out.println("ENTER A DATE TO LOOK UP BORROWED TAPES FOR GIVEN DATE AND PRESS ENTER:\n");
        System.out.println("Date: ");       inputDate = scanner.nextLine();

        Date lookupDate = ConversionService.stringToDate(inputDate);
        ValidationResponse tapeReportValidation = tapeReportValid(lookupDate);
        if (tapeReportValidation.modelIsValid())
        {
            List<BorrowedTapeDetails> borrowedTapes = borrowService.getBorrowedTapes(lookupDate);
            if(borrowedTapes.size() == 0)
            {
                System.out.println("== NO TAPES CURRENTLY BEING BORROWED FOR GIVEN DATE == ");
                return;
            }
            for(int i = 0; i < borrowedTapes.size(); i++)
            {
                System.out.println(i+1 + ".");
                System.out.println(borrowedTapes.get(i));
            }
            return;
        }

        /* error message if date could not be parsed */
        System.out.println("\nERROR: report can not be created.");
        System.out.println(tapeReportValidation.getErrorMsg());
    }

    private ValidationResponse tapeReportValid(Date lookupDate)
    {
        ValidationResponse validationResult = new ValidationResponse();
        if (lookupDate == null)
        {
            validationResult.setModelValidation(false);
            validationResult.addError("Input must be a valid date");
        }
        return validationResult;
    }
}
