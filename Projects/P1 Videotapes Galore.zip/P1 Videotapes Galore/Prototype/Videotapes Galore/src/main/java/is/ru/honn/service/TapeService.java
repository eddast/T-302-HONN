/*
 * @(#)TapeService.java 1.0 26 Sep 2018 Edda Steinunn Rúnarsdóttir
 *
 * Copyright (c) Edda Steinunn Rúnarsdóttir
 */
package is.ru.honn.service;

import is.ru.honn.model.Tape;

import java.util.Date;

/**
 * Interface TapeService (TapeService.java)
 * Actions a tape service needs to implement
 *
 * @author Edda Steinunn Rúnarsdóttir
 * @version 1.0, 26 Sep 2018
 */
public interface TapeService
{
    /**
     * Register new tape to system by title, director, type, date and EIDR no with predefined id
     *
     * @param id
     * @param title
     * @param director
     * @param type
     * @param releaseDate
     * @param EIDR
     */
    void registerTape(int id, String title, String director, String type, Date releaseDate, String EIDR);
    /**
     * Register new tape to system by title, director, type, date and EIDR no, id assigned
     *
     * @param title
     * @param director
     * @param type
     * @param releaseDate
     * @param EIDR
     */
    void registerTape(String title, String director, String type, Date releaseDate, String EIDR);
    /**
     * Gets tape by id number
     *
     * @param id id number of tape
     */
    Tape getTapeById(int id) throws ResourceNotFoundException;
}
