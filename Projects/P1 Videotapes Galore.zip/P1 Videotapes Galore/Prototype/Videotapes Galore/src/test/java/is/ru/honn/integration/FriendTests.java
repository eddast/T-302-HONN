package is.ru.honn.integration;

import is.ru.honn.factory.FriendServiceFactory;
import is.ru.honn.model.Friend;
import is.ru.honn.service.FriendService;
import is.ru.honn.service.ResourceNotFoundException;
import is.ru.honn.view.MainMenuUI;
import is.ru.honn.view.mainmenu.VideotapesGaloreMainMenuUI;
import org.junit.After;
import org.junit.Before;
import org.junit.Test;
import org.junit.Assert;

import java.io.*;
import java.util.Scanner;

public class FriendTests {
    MainMenuUI main = null;
    FriendService friendService;
    InputStream stream = System.in;

    @Before
    public void beforeEach()
    {
        friendService = FriendServiceFactory.getFriendService();

    }

    @After
    public void afterEach()
    {
        this.main = null;
        /* calls garbage collector */
        System.gc();
        System.setIn(stream);
    }

    @Test
    public void addFriend()
    {
        File file = new File("src/test/java/is/ru/honn/input/AddFriendInput.txt");
        try
        {
            try
            {
                friendService.getFriendById(1);
                Assert.fail("Friend should not exists in system");
            }
            catch (ResourceNotFoundException e)
            {
                Assert.assertEquals(e.getMessage(), "Friend with id 1 not found");
            }

            Scanner scanner = new Scanner(file);
            this.main = new VideotapesGaloreMainMenuUI(scanner);
            main.start();
            /* The friend is automatically read from scanner since it uses the file stream */
            Friend friendReceived = friendService.getFriendById(1);
            Friend friendExpected = new Friend(1, "Edda Steinunn", "Hlíðarhjalli 67", "eddasr15@ru.is", "8447818");
            Assert.assertEquals(friendReceived.getName(), friendExpected.getName());
            Assert.assertEquals(friendReceived.getAddress(), friendExpected.getAddress());
            Assert.assertEquals(friendReceived.getEmail(), friendExpected.getEmail());
            Assert.assertEquals(friendReceived.getTelephone(), friendExpected.getTelephone());
        }
        catch (FileNotFoundException e)
        {
            Assert.fail("Invalid filepath read for addFriend testcase");
        }
    }

}
