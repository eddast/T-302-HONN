/*
 * @(#)DataReader.java 1.0 26 Sep 2018 Edda Steinunn Rúnarsdóttir
 *
 * Copyright (c) Edda Steinunn Rúnarsdóttir
 */
package is.ru.honn.parser;

import is.ru.honn.factory.BorrowServiceFactory;
import is.ru.honn.factory.FriendServiceFactory;
import is.ru.honn.factory.TapeServiceFactory;
import is.ru.honn.service.BorrowService;
import is.ru.honn.service.FriendService;
import is.ru.honn.service.TapeService;
import org.json.simple.JSONArray;
import org.json.simple.JSONObject;

import java.text.SimpleDateFormat;
import java.util.Date;

/**
 * Class BorrowDataParser (BorrowDataParser.java)
 * Reads in JSON data files on friends and tapes and adds them to system one by one
 * Also registers borrows of friends on tapes when reading in friends
 *
 * @author Edda Steinunn Rúnarsdóttir
 * @version 1.0, 26 Sep 2018
 */
public class BorrowDataParser implements DataParser
{
    /**
     * borrow service to register borrows to system
     */
    private BorrowService borrowService;
    /**
     * friend service to register friends to system
     */
    private FriendService friendService;
    /**
     * tape service to register tapes to system
     */
    private TapeService tapeService;


    /**
     * Initialise services
     */
    public BorrowDataParser()
    {
        borrowService = BorrowServiceFactory.getBorrowService();
        friendService = FriendServiceFactory.getFriendService();
        tapeService = TapeServiceFactory.getTapeService();
    }

    /**
     * Reads in tapes, friends and borrows from JSON data file and adds them to system
     */
    public void initializeSystem()
    {
        parseTapes();
        parseFriends();
    }
    /**
     * Reads in friends from JSON data file and adds them to system
     */
    public void parseFriends()
    {
        JSONArray friendsJSON = DataReader.readJSON("src/main/java/is/ru/honn/data/Friends.json");

        /* parse each friend encountered */
        for (Object friendJSON : friendsJSON)
        {
            JSONObject friend = (JSONObject) friendJSON;

            /* extract values needed to register new friend */
            int friendId = ((Long) friend.get("id")).intValue();
            String name = (friend.get("first_name")) + " " + (friend.get("last_name"));
            String address = (String) friend.get("address");
            String email = (String) friend.get("email");
            String telephone = (String) friend.get("phone");

            try
            {
                /* register new friend if data is OK */
                friendService.registerFriend(friendId, name, address, email, telephone);

                /* then, if friend has borrowed tapes assigned to him/her, register all borrows */
                registerBorrowedTapes(friendId, (JSONArray) friend.get("tapes"));
            } catch (Exception e)
            {
                // TODO data not correctly formatted
                e.printStackTrace();
            }
        }
    }
    /**
     * Registered tapes borrowed by friend
     *
     * @param borrowerId friend id to register borrows for
     * @param tapes list of tapes to register as borrowed to friend
     */
    private void registerBorrowedTapes(int borrowerId, JSONArray tapes)
    {
        if(tapes != null)
        {
            for (Object tapeJSON : tapes)
            {
                JSONObject tape = (JSONObject) tapeJSON;

                /* extract value needed to register new tape */
                int tapeId = ((Long) tape.get("id")).intValue();
                String borrowDateStr = (String) tape.get("borrow_date");
                String returnDateStr = (String) tape.get("return_date");
                try
                {
                    /* register borrow record if data is OK */
                    Date borrowDate = new SimpleDateFormat("yyyy-MM-dd").parse(borrowDateStr);
                    if (returnDateStr == null)
                    {
                        borrowService.registerBorrow(borrowerId, tapeId, borrowDate);
                    }
                    else
                    {
                        Date returnDate = new SimpleDateFormat("yyyy-MM-dd").parse(returnDateStr);
                        borrowService.registerBorrow(borrowerId, tapeId, borrowDate, returnDate);

                    }
                } catch (Exception e)
                {
                    // TODO data not correctly formatted
                    e.printStackTrace();
                }
            }
        }
    }
    /**
     * Reads in video tapes from JSON data file and adds them to system
     */
    public void parseTapes()
    {
        JSONArray tapesJSON = DataReader.readJSON("src/main/java/is/ru/honn/data/Tapes.json");

        /* parse each tapes encountered */
        for (Object tapeJSON : tapesJSON)
        {
            JSONObject tape = (JSONObject) tapeJSON;

            /* extract values needed to register new tape */
            int tapeId = ((Long) tape.get("id")).intValue();
            String title = (String) tape.get("title");
            String director = tape.get("director_first_name") + " " + tape.get("director_last_name");
            String type = (String) tape.get("type");
            String releaseDateStr = (String) tape.get("release_date");
            String eidr = (String) tape.get("eidr");
            try
            {
                /* register tape record if data is OK */
                Date releaseDate = new SimpleDateFormat("yyyy-MM-dd").parse(releaseDateStr);
                tapeService.registerTape(tapeId, title, director, type, releaseDate, eidr);
            } catch (Exception e)
            {
                // TODO data not correctly formatted
                e.printStackTrace();
            }
        }
    }
}
