/*
 * @(#)Friend.java 1.0 26 Sep 2018 Edda Steinunn Rúnarsdóttir
 *
 * Copyright (c) Edda Steinunn Rúnarsdóttir
 */
package is.ru.honn.model;

/**
 * Class Friend (Friend.java)
 * Data type representing friend
 *
 * @author Edda Steinunn Rúnarsdóttir
 * @version 1.0, 26 Sep 2018
 */
public class Friend
{
    /**
     * Friend's id
     */
    private int id;
    /**
     * Friend's name
     */
    private String name;
    /**
     * Friend's address
     */
    private String address;
    /**
     * Friend's email
     */
    private String email;
    /**
     * Friend's telephone no
     */
    private String telephone;


    /**
     * Constructs friend data type
     * @param name
     * @param address
     * @param email
     * @param telephone
     */
    public Friend(int id, String name, String address, String email, String telephone)
    {
        this.id = id;
        this.name = name;
        this.address = address;
        this.email = email;
        this.telephone = telephone;
    }
    /**
     * @return friend's id
     */
    public int getId()
    {
        return id;
    }
    /**
     * @return friend's name
     */
    public String getName()
    {
        return name;
    }
    /**
     * @param name new name for friend
     */
    public void setName(String name)
    {
        this.name = name;
    }
    /**
     * @return friend's address
     */
    public String getAddress()
    {
        return address;
    }
    /**
     * @return friend's email
     */
    public String getEmail()
    {
        return email;
    }
    /**
     * @return friend's telephone no
     */
    public String getTelephone()
    {
        return telephone;
    }
}
