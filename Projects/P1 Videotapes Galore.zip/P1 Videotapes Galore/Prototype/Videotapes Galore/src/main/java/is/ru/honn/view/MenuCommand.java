/*
 * @(#)MenuCommand.java 1.0 26 Sep 2018 Edda Steinunn Rúnarsdóttir
 *
 * Copyright (c) Edda Steinunn Rúnarsdóttir
 */
package is.ru.honn.view;

/**
 * Interface MenuCommand (MenuCommand.java)
 * Defines functionality a main mainmenu command should have
 *
 * @author Edda Steinunn Rúnarsdóttir
 * @version 1.0, 26 Sep 2018
 */
public interface MenuCommand
{
    /**
     * @return main mainmenu name of command
     */
    String getCommandName();
    /**
     * Executes specified command
     */
    void executeCommand();
}
