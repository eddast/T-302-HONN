/*
 * @(#)ReportBorrowersOverMonthUICommand.java 1.0 26 Sep 2018 Edda Steinunn Rúnarsdóttir
 *
 * Copyright (c) Edda Steinunn Rúnarsdóttir
 */
package is.ru.honn.view.mainmenu.options.submenu.options;

import is.ru.honn.factory.BorrowServiceFactory;
import is.ru.honn.factory.ScannerFactory;
import is.ru.honn.model.Borrower;
import is.ru.honn.model.ValidationResponse;
import is.ru.honn.service.BorrowService;
import is.ru.honn.service.ConversionService;
import is.ru.honn.view.MenuCommand;

import java.util.Date;
import java.util.List;
import java.util.Scanner;

/**
 * Class ReportBorrowersOverMonthUICommand (ReportBorrowersOverMonthUICommand.java)
 * Outputs a list of all friends borrowing tapes from over a month ago (along with which tapes they're borrowing)
 *
 * @author Edda Steinunn Rúnarsdóttir
 * @version 1.0, 26 Sep 2018
 */
public class ReportBorrowersOverMonthUICommand implements MenuCommand
{
    /**
     * Borrow service to manipulate borrow records in system
     */
    private BorrowService borrowService;
    /**
     * Scanner to use for system input
     */
    private Scanner scanner;

    /**
     * Gets borrow service to manipulate borrow record list
     */
    public ReportBorrowersOverMonthUICommand(Scanner scanner)
    {
        this.scanner = scanner;
        borrowService = BorrowServiceFactory.getBorrowService();
    }
    /**
     * Gets borrow service to manipulate borrow record list
     */
    public ReportBorrowersOverMonthUICommand()
    {
        scanner = new Scanner(System.in);
        borrowService = BorrowServiceFactory.getBorrowService();
    }
    /**
     * @return name of this command to display in main mainmenu
     */
    public String getCommandName()
    {
        return "Output list of Friends Borrowing Tapes From Over A Month Ago";
    }
    /**
     * Outputs list of borrowed tapes (along with with their borrower)
     */
    public void executeCommand()
    {
        String inputDate = "";
        System.out.println("ENTER A DATE TO LOOK UP BORROWERS FOR GIVEN DATE AND PRESS ENTER:\n");
        System.out.println("Date: ");       inputDate = scanner.nextLine();

        Date lookupDate = ConversionService.stringToDate(inputDate);
        ValidationResponse lateReportValidation = lateReportValid(lookupDate);
        if (lateReportValidation.modelIsValid()) {
            List<Borrower> borrowers = borrowService.getBorrowersOverAMonth(lookupDate);
            if (borrowers.size() == 0) {
                System.out.println("== NO FRIENDS CURRENTLY BORROWING ANY TAPES FROM OVER A MONTH AGO FOR GIVEN DATE == ");
                return;
            }
            for (int i = 0; i < borrowers.size(); i++) {
                System.out.println(i + 1 + ".");
                System.out.println(borrowers.get(i));
            }
            return;
        }
        /* error message if date could not be parsed */
        System.out.println("\nERROR: report can not be created.");
        System.out.println(lateReportValidation.getErrorMsg());
    }

    private ValidationResponse lateReportValid(Date lookupDate)
    {
        ValidationResponse validationResult = new ValidationResponse();
        if (lookupDate == null)
        {
            validationResult.setModelValidation(false);
            validationResult.addError("Input must be a valid date");
        }
        return validationResult;
    }
}
