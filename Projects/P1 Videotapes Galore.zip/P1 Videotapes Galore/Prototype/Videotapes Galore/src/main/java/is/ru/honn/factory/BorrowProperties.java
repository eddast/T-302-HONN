package is.ru.honn.factory;

import java.io.FileInputStream;
import java.io.IOException;
import java.io.InputStream;
import java.util.Properties;

public class BorrowProperties {
    private static Properties props = null;

    public static Class getClassFromProperty(String property)
    {
        if (props == null)
        {
            loadProperties();
        }

        // get the property value and print it out
        Class c = null;
        try
        {
            c = Class.forName(props.getProperty(property));
        }
        catch (ClassNotFoundException e)
        {
            e.printStackTrace();
        }
        return c;
    }

    private static void loadProperties()
    {
        props = new Properties();
        InputStream input = null;
        try
        {
            input = new FileInputStream("project.properties");

            // load the properties file
            props.load(input);

        }
        catch (IOException e)
        {
            e.printStackTrace();
        }
        if (input != null)
        {
            try
            {
                input.close();
            }
            catch (IOException e)
            {
                e.printStackTrace();
            }
        }
    }
}
