/*
 * @(#)VideotapesGaloreMainMenuUI.java 1.0 26 Sep 2018 Edda Steinunn Rúnarsdóttir
 *
 * Copyright (c) Edda Steinunn Rúnarsdóttir
 */
package is.ru.honn.view.mainmenu;

import is.ru.honn.view.AbstractMainMenuUI;
import is.ru.honn.view.MenuCommand;
import is.ru.honn.view.mainmenu.options.*;

import java.util.Scanner;

/**
 * Class VideotapesGaloreMainMenuUI (VideotapesGaloreMainMenuUI.java)
 * Interacts with and provides instructions to system users of VIDEOTAPES GALORE system
 * Decides which functionality/actions to execute by receiving user input
 *
 * @author Edda Steinunn Rúnarsdóttir
 * @version 1.0, 26 Sep 2018
 */
public class VideotapesGaloreMainMenuUI extends AbstractMainMenuUI
{
    /**
     * Set up options available for videotapes galore and scanner
     */
    public VideotapesGaloreMainMenuUI(Scanner scanner)
    {
        this.scanner = scanner;
        this.commandsAvailable = new MenuCommand[] {
                new RegisterFriendUICommand(scanner),
                new RegisterTapeUICommand(scanner),
                new RegisterBorrowUICommand(scanner),
                new RegisterReturnDateCommand(scanner),
                new BorrowReportsUICommand(scanner)
        };
    }
    /**
     * Set up options available for videotapes galore and new scanner for System.in
     */
    public VideotapesGaloreMainMenuUI()
    {
        this.scanner = new Scanner(System.in);
        this.commandsAvailable = new MenuCommand[] {
                new RegisterFriendUICommand(),
                new RegisterTapeUICommand(),
                new RegisterBorrowUICommand(),
                new RegisterReturnDateCommand(),
                new BorrowReportsUICommand()
        };
    }
    /**
     * Prints message welcoming user to videotapes galore
     */
    public void printWelcomeMessage()
    {
        System.out.println("\n========================================\n");
        System.out.println("  WELCOME TO VIDEOTAPES GALORE");
        System.out.println("  Keeping your video tapes well-managed!");
        System.out.println("\n========================================\n");
    }
    /**
     * Prints message explicitly indicating user he has quit system
     */
    public void printQuitMessage()
    {
        System.out.println("Quitting VIDEOTAPES GALORE");
        System.out.println("Thank you, come back soon! :)");
    }
    /**
     * @return on quit option
     */
    public String getQuitOption()
    {
        return "Quit VIDEOTAPES GALORE";
    }
}
