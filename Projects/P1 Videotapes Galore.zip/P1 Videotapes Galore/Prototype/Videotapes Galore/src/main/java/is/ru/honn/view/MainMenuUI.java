/*
 * @(#)MainMenuUI.java 1.0 26 Sep 2018 Edda Steinunn Rúnarsdóttir
 *
 * Copyright (c) Edda Steinunn Rúnarsdóttir
 */
package is.ru.honn.view;

/**
 * Interface MainMenuUI (MainMenuUI.java)
 * Defines which functionality main-mainmenu based system has
 * i.e. system that displays main mainmenu, then prompts user for command from mainmenu, then executes it
 *
 * @author Edda Steinunn Rúnarsdóttir
 * @version 1.0, 26 Sep 2018
 */
public interface MainMenuUI
{
    /**
     * Starts system
     */
    void start();
    /**
     * @param command id of main mainmenu command to execute
     */
    void executeCommand(int command);
    /**
     * @param input user inputted command
     * @return true if command is valid in system, false otherwise
     */
    boolean commandIsValid(String input);
    /**
     * @param input user inputted command
     * @return true if user wants to quit system
     */
    boolean wantsToQuit(int input);
    /**
     * Prints main mainmenu (available options)
     */
    void printMainMenu();
    /**
     * Print error message on invalid command
     */
    void printCommandInvalidError();
    /**
     * Prints welcome message on start
     */
    void printWelcomeMessage();
    /**
     * Prints quit message on exit
     */
    void printQuitMessage();
    /**
     * Prints quit mainmenu indication (last main mainmenu command)
     */
    String getQuitOption();
}

