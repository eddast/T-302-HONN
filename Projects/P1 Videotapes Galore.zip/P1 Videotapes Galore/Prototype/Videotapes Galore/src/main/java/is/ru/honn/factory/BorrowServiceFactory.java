/*
 * @(#)BorrowServiceFactory.java 1.0 26 Sep 2018 Edda Steinunn Rúnarsdóttir
 *
 * Copyright (c) Edda Steinunn Rúnarsdóttir
 */
package is.ru.honn.factory;

import is.ru.honn.service.BorrowMemoryService;
import is.ru.honn.service.BorrowService;

/**
 * Class BorrowServiceFactory (BorrowServiceFactory.java)
 * Gets static instance of borrow service for classes to use
 *
 * @author Edda Steinunn Rúnarsdóttir
 * @version 1.0, 26 Sep 2018
 */
public class BorrowServiceFactory
{
    /**
     * Static instance of friend service
     */
    private static BorrowService borrowService = null;


    /**
     * Gets borrow service for classes to use
     *
     * @return friend service
     */
    public static BorrowService getBorrowService()
    {
        if(borrowService == null)
        {
            Class c = BorrowProperties.getClassFromProperty("borrow");
            try
            {
                borrowService = (BorrowService) c.newInstance();
            }
            catch (InstantiationException e)
            {
                e.printStackTrace();
            }
            catch (IllegalAccessException e)
            {
                e.printStackTrace();
            }
        }
        return borrowService;
    }
}
