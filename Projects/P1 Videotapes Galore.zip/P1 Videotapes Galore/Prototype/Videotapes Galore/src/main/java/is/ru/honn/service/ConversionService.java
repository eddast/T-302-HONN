package is.ru.honn.service;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Date;

public class ConversionService {
    /**
     * @param date string for date
     * @return date in date format from string or null if invalid date
     */
    public static Date stringToDate(String date)
    {
        /* Attempt to parse date sting */
        try
        {
            return new SimpleDateFormat("yyyy-MM-dd").parse(date);
        }
        /* error if date is incorrectly formatted (return null) */
        catch (ParseException e)
        {
            return null;
        }
    }
    /**
     * @param id string id to convert to integer
     * @return integer value for id or -1 if invalid number
     */
    public static int idToInt(String id)
    {
        /* Attempt to convert sting to int */
        try
        {
            return Integer.parseInt(id);
        }
        /* error if string not a valid int (return -1) */
        catch (NumberFormatException e)
        {
            return -1;
        }
    }
}
