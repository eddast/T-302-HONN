/*
 * @(#)BorrowMemoryService.java 1.0 26 Sep 2018 Edda Steinunn Rúnarsdóttir
 *
 * Copyright (c) Edda Steinunn Rúnarsdóttir
 */
package is.ru.honn.service;

import is.ru.honn.factory.FriendServiceFactory;
import is.ru.honn.factory.TapeServiceFactory;
import is.ru.honn.model.*;

import java.util.ArrayList;
import java.util.Calendar;
import java.util.Date;
import java.util.List;

/**
 * Class BorrowMemoryService (BorrowMemoryService.java)
 * Implements read/modify actions for borrows of tapes to friends in system
 * And manages all borrows in system
 *
 * @author Edda Steinunn Rúnarsdóttir
 * @version 1.0, 26 Sep 2018
 */
public class BorrowMemoryService implements BorrowService
{
    /**
     * List of all records of borrows
     */
    private List<BorrowRecord> borrows;
    /**
     * Friend service to access list of friends
     */
    private FriendService friendService;
    /**
     * Tape service to access list of tapes
     */
    private TapeService tapeService;


    /**
     * Initializes borrow service with empty borrow records and service used
     */
    public BorrowMemoryService()
    {
        borrows = new ArrayList<BorrowRecord>();
        friendService = FriendServiceFactory.getFriendService();
        tapeService = TapeServiceFactory.getTapeService();
    }
    /**
     * Registers borrow of tape to a friend without specified borrowDate
     *
     * @param borrowerId id of friend to borrow tape to
     * @param tapeId id of tape to borrow to friend
     * @param borrowDate date of borrow
     * @throws BorrowException if borrow can't be registered
     */
    public void registerBorrow(int borrowerId, int tapeId, Date borrowDate) throws BorrowException
    {
        validateBorrow(borrowerId, tapeId);
        BorrowRecord borrow = new BorrowRecord(borrowerId, tapeId, borrowDate);
        borrows.add(borrow);
    }
    /**
     * Registers borrow of tape to a friend
     *
     * @param borrowerId id of friend to borrow tape to
     * @param tapeId id of tape to borrow to friend
     * @param borrowDate date of borrow
     * @param returnDate date when tape was returned
     * @throws BorrowException if borrow can't be registered
     */
    public void registerBorrow(int borrowerId, int tapeId, Date borrowDate, Date returnDate) throws BorrowException
    {
        validateBorrow(borrowerId, tapeId);
        BorrowRecord borrow = new BorrowRecord(borrowerId, tapeId, borrowDate, returnDate);
        borrows.add(borrow);
    }
    /**
     * Borrows a given tape to friend
     *
     * @param borrowerId id of friend to borrow tape to
     * @param tapeId id of tape to borrow to friend
     * @param returnDate date when tape was returned
     * @throws BorrowException if tape is already borrowed
     */
    public void returnTape(int borrowerId, int tapeId, Date returnDate) throws BorrowException
    {
        validateReturn(borrowerId, tapeId);
        if (returnDate == null) {
            throw new BorrowException("Return date can't be null");
        }
        for (int i = 0; i < borrows.size(); i++) {
            BorrowRecord borrowRecord = borrows.get(i);
            if (borrowRecord.getTapeID() == tapeId && borrowRecord.getBorrowerID() == borrowerId) {
                borrowRecord.setReturnDate(returnDate);
                return;
            }
        }
        throw new BorrowException("Borrow Record for friend with id " + borrowerId + " and tape with id " + tapeId + " not found");
    }

    /**
     * @return list of all borrowed tapes in system (with it's borrowers)
     */
    public List<BorrowedTapeDetails> getBorrowedTapes(Date lookupDate)
    {
        ArrayList<BorrowedTapeDetails> borrowedTapes = new ArrayList<BorrowedTapeDetails>();

        /* iterate through all borrows in system */
        for(int i = 0; i < borrows.size(); i++)
        {
            BorrowRecord record = borrows.get(i);
            if (record.getBorrowDate().before(lookupDate) && (record.getReturnDate() == null || record.getReturnDate().after(lookupDate)))
            {
                /* extract tape and borrower from current entry of borrow then add it to borrowed tapes */
                Tape tape = tapeService.getTapeById(record.getTapeID());
                Friend borrower = friendService.getFriendById(record.getBorrowerID());
                BorrowedTapeDetails borrowedTape = new BorrowedTapeDetails(tape, borrower.getId(), borrower.getName(), record.getBorrowDate());
                borrowedTapes.add(borrowedTape);
            }
        }

        return borrowedTapes;
    }
    /**
     * @return list of all borrowers in system (with it's borrowed tapes)
     */
    public List<Borrower> getBorrowers(Date lookupDate)
    {
        ArrayList<Borrower> borrowers = new ArrayList<Borrower>();

        /* iterate through all borrows in system */
        for(int i = 0; i < borrows.size(); i++)
        {
            BorrowRecord record = borrows.get(i);
            if (record.getBorrowDate().before(lookupDate) && (record.getReturnDate() == null || record.getReturnDate().after(lookupDate)))
            {
                constructSingleBorrowerEntryFromRecord(record, borrowers);
            }
        }

        return borrowers;
    }
    /**
     * @return list of friends that have had a tape borrowed for over a month
     */
    public List<Borrower> getBorrowersOverAMonth(Date lookupDate)
    {
        ArrayList<Borrower> borrowers = new ArrayList<Borrower>();

        /* get date one month before today's date */
        Calendar monthBefore = Calendar.getInstance();
        monthBefore.setTime(lookupDate);
        monthBefore.add(Calendar.MONTH, -1 );

        /* iterate through all borrows in system */
        for(int i = 0; i < borrows.size(); i++)
        {
            BorrowRecord record = borrows.get(i);
            if (record.getBorrowDate().before(lookupDate) && (record.getReturnDate() == null || record.getReturnDate().after(lookupDate)))
            {
                /* Construct calendar object for borrow date to compare to month before*/
                Calendar borrowDate = Calendar.getInstance();
                borrowDate.setTime(borrows.get(i).getBorrowDate());
                if(monthBefore.after(borrowDate))
                {
                    constructSingleBorrowerEntryFromRecord(borrows.get(i), borrowers);
                }
            }
        }
        return borrowers;
    }

    /**
     * Gets borrow record by borrowerId and tapeId
     * @param borrowerId
     * @param tapeId
     * @return
     * @throws BorrowException
     */
    public BorrowRecord getRecord(int borrowerId, int tapeId)
    {
        for(int i = 0; i < borrows.size(); i++)
        {
            BorrowRecord borrowRecord = borrows.get(i);
            if (borrowRecord.getBorrowerID() == borrowerId && borrowRecord.getTapeID() == tapeId)
            {
                return borrowRecord;
            }
        }
        return null;
    }
    /**
     * Constructs a single borrower entry (i.e. friend with all his or her borrowed tapes) from a borrow record
     *
     * @param record borrow record to construct borrower entry from
     * @param borrowers list of borrowers yet encountered
     */
    private void constructSingleBorrowerEntryFromRecord(BorrowRecord record, ArrayList<Borrower> borrowers)
    {
        /* extract tape and borrower from current entry of borrow */
        Tape tape = tapeService.getTapeById(record.getTapeID());
        Friend borrower = friendService.getFriendById(record.getBorrowerID());
        BorrowedTape borrowedTape = new BorrowedTape(tape.getId(), tape.getTitle(), record.getBorrowDate());

        /* iterate through borrowers encountered */
        /* if borrower has already been encountered, add tape to that borrower in list */
        boolean borrowerAlreadyInBorrowerList = false;
        for(int i = 0; i < borrowers.size(); i++)
        {
            borrowerAlreadyInBorrowerList = borrowers.get(i).getBorrower().getId() == borrower.getId();
            if(borrowerAlreadyInBorrowerList)
            {
                borrowers.get(i).addTapeToBorrower(borrowedTape);
                break;
            }
        }
        /* if we've not already encountered borrower, add borrower to borrower list as new borrower */
        if(!borrowerAlreadyInBorrowerList)
        {
            Borrower newBorrower = new Borrower(borrower);
            newBorrower.addTapeToBorrower(borrowedTape);
            borrowers.add(newBorrower);
        }
    }
    /**
     * Checks if borrow is valid, i.e. if borrower and if tape exists and is available
     *
     * @param borrowerId id of potential borrower
     * @param tapeId id of specified tape
     * @throws BorrowException if borrow is invalid
     */
    private void validateBorrow(int borrowerId, int tapeId) throws BorrowException {
        /* Error if date borrower/friend does not exist in system */
        try
        {
            friendService.getFriendById(borrowerId);
        }
        catch (ResourceNotFoundException e)
        {
            throw new BorrowException(e.getMessage());
        }
        /* Error if date tape does not exist in system */
        try
        {
            tapeService.getTapeById(tapeId);
        }
        catch (ResourceNotFoundException e)
        {
            throw new BorrowException(e.getMessage());
        }
        /* Error if tape is already being borrowed */
        if(tapeNotAvailable(tapeId))
        {
            System.out.println(tapeId);
            throw new BorrowException("Tape already being borrowed");
        }
    }

    private void validateReturn(int borrowerId, int tapeId) throws BorrowException {
        /* Error if date borrower/friend does not exist in system */
        try
        {
            friendService.getFriendById(borrowerId);
        }
        catch (ResourceNotFoundException e)
        {
            throw new BorrowException(e.getMessage());
        }
        /* Error if date tape does not exist in system */
        try
        {
            tapeService.getTapeById(tapeId);
        }
        catch (ResourceNotFoundException e)
        {
            throw new BorrowException(e.getMessage());
        }
        /* Error if tape is already being borrowed */
        if (!friendBorrowingTape(borrowerId, tapeId))
        {
            System.out.println(tapeId);
            throw new BorrowException("Cannot return tape, the friend isn't borrowing the specified tape");
        }
    }
    /**
     * @param borrowerId id of friend to check if he/she is borrowing the tape
     * @param tapeId id of tape to check if the friend is borrowing it
     * @return true if tape is available, i.e. has not been borrowed
     */
    private boolean friendBorrowingTape(int borrowerId, int tapeId)
    {
        for(int i = 0; i < borrows.size(); i++)
        {
            BorrowRecord borrowRecord = borrows.get(i);
            if (borrowRecord.getTapeID() == tapeId)
            {
                return borrowRecord.getBorrowerID() == borrowerId;
            }
        }
        return false;
    }
    /**
     * @param tapeId id of tape to check for availability
     * @return true if tape is available, i.e. has not been borrowed
     */
    private boolean tapeNotAvailable(int tapeId)
    {
        for(int i = 0; i < borrows.size(); i++)
        {
            BorrowRecord record = borrows.get(i);
            if(record.getTapeID() == tapeId)
            {
                if (record.notReturned())
                {
                    return true;
                }
            }
        }
        return false;
    }
}
