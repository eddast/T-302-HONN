/*
 * @(#)FriendService.java 1.0 26 Sep 2018 Edda Steinunn Rúnarsdóttir
 *
 * Copyright (c) Edda Steinunn Rúnarsdóttir
 */
package is.ru.honn.service;

import is.ru.honn.model.Friend;

/**
 * Interface FriendService (FriendService.java)
 * Actions a friend service needs to implement
 *
 * @author Edda Steinunn Rúnarsdóttir
 * @version 1.0, 26 Sep 2018
 */
public interface FriendService
{
    /**
     * Register new friend to system
     *
     * @param name
     * @param address
     * @param email
     * @param telephone
     */
    void registerFriend (String name, String address, String email, String telephone);
    /**
     * Register new friend to system with predefined id
     *
     * @param name
     * @param address
     * @param email
     * @param telephone
     */
    void registerFriend (int id, String name, String address, String email, String telephone);
    /**
     * Gets friend by id
     *
     * @param id id of friend
     */
    Friend getFriendById (int id) throws ResourceNotFoundException;
}
