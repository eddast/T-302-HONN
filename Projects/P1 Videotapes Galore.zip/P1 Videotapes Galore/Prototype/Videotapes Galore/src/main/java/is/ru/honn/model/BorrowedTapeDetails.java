/*
 * @(#)BorrowedTapeDetails.java 1.0 26 Sep 2018 Edda Steinunn Rúnarsdóttir
 *
 * Copyright (c) Edda Steinunn Rúnarsdóttir
 */
package is.ru.honn.model;

import java.util.Date;

/**
 * Class BorrowedTapeDetails (BorrowedTapeDetails.java)
 * Data type representing borrowed tape with all details
 * i.e. including the tape object with borrow date and name id of borrower
 *
 * @author Edda Steinunn Rúnarsdóttir
 * @version 1.0, 26 Sep 2018
 */
public class BorrowedTapeDetails
{
    /**
     * The borrowed tape
     */
    private Tape tape;
    /**
     * Borrowed tape borrower's name
     */
    private String borrowerName;
    /**
     * Borrowed tape borrower's id
     */
    private int borrowerId;
    /**
     * Date when tape was borrowed
     */
    private Date borrowDate;


    /**
     * Empty constructor
     */
    public BorrowedTapeDetails()
    {

    }
    /**
     * Constructs a borrowed tape
     *
     * @param tape the borrowed tape
     * @param borrowerId borrowed tape borrower's name
     * @param borrowerName borrowed tape borrower's id
     * @param borrowDate date when tape was borrowed
     */
    public BorrowedTapeDetails(Tape tape, int borrowerId, String borrowerName, Date borrowDate)
    {
        this.tape = tape;
        this.borrowerId = borrowerId;
        this.borrowerName = borrowerName;
        this.borrowDate = borrowDate;
    }
    /**
     * @return the borrowed tape
     */
    public Tape getTape()
    {
        return tape;
    }
    /**
     * @return id of tape borrower
     */
    public int getBorrowerId()
    {
        return borrowerId;
    }
    /**
     * @return name of tape borrower
     */
    public String getBorrowerName()
    {
        return borrowerName;
    }
    /**
     * @return date when tape was borrowed
     */
    public Date getBorrowDate()
    {
        return borrowDate;
    }
    /**
     * @return string representing borrowed tape entry
     */
    public String toString()
    {
        String tapeInformation = "", borrowerInformation = "";

        /* output tape information */
        borrowerInformation += "TAPE:\n";
        borrowerInformation += "\tID: " + tape.getId() + "\n";
        borrowerInformation += "\tTitle: " + tape.getTitle() + "\n";
        borrowerInformation += "\tType: " + tape.getType() + "\n";
        borrowerInformation += "\tDirector: " + tape.getDirector() + "\n";
        borrowerInformation += "\tRelease Date: " + tape.getReleaseDate() + "\n";
        borrowerInformation += "\tEIDR Number: " + tape.getEIDR() + "\n";
        borrowerInformation += "\tDATE BORROWED: " + borrowDate + "\n";

        /* output tape's borrower information  */
        borrowerInformation  +=  "BORROWER:\n";
        borrowerInformation += "ID: " + borrowerId;
        borrowerInformation += ", Name: " + borrowerName;

        return tapeInformation + borrowerInformation + "\n";
    }
}
