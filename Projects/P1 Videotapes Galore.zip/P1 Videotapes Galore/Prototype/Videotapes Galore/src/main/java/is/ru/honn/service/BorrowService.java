/*
 * @(#)BorrowService.java 1.0 26 Sep 2018 Edda Steinunn Rúnarsdóttir
 *
 * Copyright (c) Edda Steinunn Rúnarsdóttir
 */
package is.ru.honn.service;

import is.ru.honn.model.BorrowRecord;
import is.ru.honn.model.BorrowedTapeDetails;
import is.ru.honn.model.Borrower;

import java.util.Date;
import java.util.List;

/**
 * Interface BorrowService (BorrowService.java)
 * Defines read/modify actions for borrows of tapes to friends in system
 *
 * @author Edda Steinunn Rúnarsdóttir
 * @version 1.0, 26 Sep 2018
 */
public interface BorrowService
{
    /**
     * Borrows a given tape to friend
     *
     * @param borrowerId id of friend to borrow tape to
     * @param tapeId id of tape to borrow to friend
     * @param borrowDate date of borrow
     * @throws BorrowException if tape is already borrowed
     */
    void registerBorrow (int borrowerId, int tapeId, Date borrowDate) throws BorrowException;
    /**
     * Borrows a given tape to friend
     *
     * @param borrowerId id of friend to borrow tape to
     * @param tapeId id of tape to borrow to friend
     * @param borrowDate date of borrow
     * @param returnDate date when tape was returned
     * @throws BorrowException if tape is already borrowed
     */
    void registerBorrow (int borrowerId, int tapeId, Date borrowDate, Date returnDate) throws BorrowException;
    /**
     * Borrows a given tape to friend
     *
     * @param borrowerId id of friend to borrow tape to
     * @param tapeId id of tape to borrow to friend
     * @param returnDate date when tape was returned
     * @throws BorrowException if tape is already borrowed
     */
    void returnTape (int borrowerId, int tapeId, Date returnDate) throws BorrowException;

    BorrowRecord getRecord(int borrowerId, int tapeId) throws BorrowException;
    /**
     * @return list of all borrowed tapes in system (with it's borrowers)
     */
    List<BorrowedTapeDetails>getBorrowedTapes (Date lookupDate);
    /**
     * @return list of all borrowers in system (with it's borrowed tapes)
     */
    List<Borrower> getBorrowers (Date lookupDate);
    /**
     * @return list of friends that have had a tape borrowed for over a month
     */
    List<Borrower> getBorrowersOverAMonth (Date lookupDate);
}
