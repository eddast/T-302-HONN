/*
 * @(#)DataReader.java 1.0 26 Sep 2018 Edda Steinunn Rúnarsdóttir
 *
 * Copyright (c) Edda Steinunn Rúnarsdóttir
 */
package is.ru.honn.parser;

import org.json.simple.JSONArray;
import org.json.simple.parser.JSONParser;
import org.json.simple.parser.ParseException;

import java.io.*;
import java.util.Properties;

/**
 * Class DataReader (DataReader.java)
 * Reads JSON files and property files
 *
 * @author Edda Steinunn Rúnarsdóttir
 * @version 1.0, 26 Sep 2018
 */
public class DataReader
{
    /**
     * Reads in JSON file
     *
     * @param JSONFile file to read JSON from
     * @return JSON from file read
     */
    public static JSONArray readJSON(String JSONFile)
    {
        JSONParser parser = new JSONParser();
        JSONArray jsonArrayFromFile = null;

        /* attempt to parse JSON */
        try
        {
            jsonArrayFromFile = (JSONArray) parser.parse( new FileReader(JSONFile));
        }
        catch (FileNotFoundException e)
        {
            e.printStackTrace();
        } catch (IOException e)
        {
            e.printStackTrace();
        } catch (ParseException e)
        {
            e.printStackTrace();
        }

        return jsonArrayFromFile;
    }
    /**
     * Reads in properties file
     *
     * @return properties from file read
     */
    public static Properties readProps(String propFile)
    {
        InputStream input = null;
        Properties prop = new Properties();
        try
        {
            input = new FileInputStream(propFile);
            prop.load(input);
        }
        catch (Exception e)
        {
            prop = null;
        }
        if(input != null)
        {
            try
            {
                input.close();
            } catch (IOException e)
            {
                e.printStackTrace();
            }
        }
        return prop;
    }
}
