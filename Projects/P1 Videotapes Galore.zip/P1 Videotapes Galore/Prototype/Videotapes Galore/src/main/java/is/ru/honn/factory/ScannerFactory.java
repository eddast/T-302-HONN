/*
 * @(#)ScannerFactory.java 1.0 26 Sep 2018 Edda Steinunn Rúnarsdóttir
 *
 * Copyright (c) Edda Steinunn Rúnarsdóttir
 */
package is.ru.honn.factory;

import java.util.Scanner;

/**
 * Class ScannerFactory (ScannerFactory.java)
 * Gets static instance of scanner to scan input for classes to use
 *
 * @author Edda Steinunn Rúnarsdóttir
 * @version 1.0, 26 Sep 2018
 */
public class ScannerFactory
{
    /**
     * Static instance of input scanner
     */
    private static Scanner inputScanner = null;

    /**
     * Gets input scanner for classes to use
     *
     * @return friend service
     */
    public static Scanner getInputScanner()
    {
        if(inputScanner == null)
        {
            inputScanner = new Scanner(System.in);
        }
        return inputScanner;
    }
}
