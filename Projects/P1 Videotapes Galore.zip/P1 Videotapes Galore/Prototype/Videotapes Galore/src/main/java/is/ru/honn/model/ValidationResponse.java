/*
 * @(#)ValidationResponse.java 1.0 26 Sep 2018 Edda Steinunn Rúnarsdóttir
 *
 * Copyright (c) Edda Steinunn Rúnarsdóttir
 */
package is.ru.honn.model;

/**
 * Class ValidationResponse (ValidationResponse.java)
 * Data type representing validation response for validating a model input
 * i.e. containing information on whether something is valid (boolean)
 * and an error message if appropriate on why it is not valid (String)
 *
 * @author Edda Steinunn Rúnarsdóttir
 * @version 1.0, 26 Sep 2018
 */
public class ValidationResponse
{
    /**
     * True if validation was successful, false otherwise
     */
    private boolean modelValidation;
    /**
     * Explicit message on on why validation was not successful
     */
    private String errorMsg;


    /**
     * Constructs default validation response
     */
    public ValidationResponse()
    {
        this.modelValidation = true;
        this.errorMsg = "";
    }
    /**
     * @return true if validation response is true
     */
    public boolean modelIsValid()
    {
        return modelValidation;
    }
    /**
     * @param modelValidation result of model validation, true if model is valid
     */
    public void setModelValidation(boolean modelValidation)
    {
        this.modelValidation = modelValidation;
    }
    /**
     * @return error message if model input is invalid
     */
    public String getErrorMsg()
    {
        return errorMsg;
    }
    /**
     * @param error append error to error message
     */
    public void addError(String error)
    {
        this.errorMsg += this.errorMsg == "" ? "- " + error : "\n- " + error;
    }
}
