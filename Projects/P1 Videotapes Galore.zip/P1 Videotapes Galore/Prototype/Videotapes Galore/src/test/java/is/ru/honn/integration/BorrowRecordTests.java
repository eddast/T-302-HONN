package is.ru.honn.integration;

import is.ru.honn.factory.BorrowServiceFactory;
import is.ru.honn.model.BorrowRecord;
import is.ru.honn.model.BorrowedTapeDetails;
import is.ru.honn.model.Friend;
import is.ru.honn.service.BorrowService;
import is.ru.honn.service.ConversionService;
import is.ru.honn.service.ResourceNotFoundException;
import is.ru.honn.view.MainMenuUI;
import is.ru.honn.view.mainmenu.VideotapesGaloreMainMenuUI;
import org.junit.After;
import org.junit.Assert;
import org.junit.Before;
import org.junit.Test;

import java.io.File;
import java.io.FileNotFoundException;
import java.io.InputStream;
import java.util.List;
import java.util.Scanner;

public class BorrowRecordTests {
    MainMenuUI main = null;
    BorrowService borrowService;
    InputStream stream = System.in;

    @Before
    public void beforeEach()
    {
        borrowService = BorrowServiceFactory.getBorrowService();

    }

    @After
    public void afterEach()
    {
        this.main = null;
        /* calls garbage collector */
        System.gc();
        System.setIn(stream);
    }

    @Test
    public void addBorrowRecord()
    {
        File file = new File("src/test/java/is/ru/honn/input/RegisterBorrow.txt");
        try
        {
            Scanner scanner = new Scanner(file);
            this.main = new VideotapesGaloreMainMenuUI(scanner);
            main.start();

            BorrowRecord record = borrowService.getRecord(1,1 );
            Assert.assertEquals(record.getBorrowDate(), ConversionService.stringToDate("2017-12-13"));
            Assert.assertEquals(record.getReturnDate(), null);
            /* Try to return the tape */
            File fileReturn = new File("src/test/java/is/ru/honn/input/ReturnTape.txt");
            scanner = new Scanner(fileReturn);
            this.main = new VideotapesGaloreMainMenuUI(scanner);
            main.start();

            /** Validate that the tape was returned **/
            BorrowRecord returnedRecord = borrowService.getRecord(1,1 );
            Assert.assertEquals(returnedRecord.getBorrowDate(), ConversionService.stringToDate("2017-12-13"));
            Assert.assertEquals(returnedRecord.getReturnDate(), ConversionService.stringToDate("2018-09-25"));
        }
        catch (FileNotFoundException e)
        {
            Assert.fail("Invalid filepath read for addFriend testcase");
        }
    }

}
