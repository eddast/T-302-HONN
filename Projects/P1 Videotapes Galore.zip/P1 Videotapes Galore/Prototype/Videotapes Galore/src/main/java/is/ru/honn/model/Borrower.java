/*
 * @(#)BorrowedTapeDetails.java 1.0 26 Sep 2018 Edda Steinunn Rúnarsdóttir
 *
 * Copyright (c) Edda Steinunn Rúnarsdóttir
 */
package is.ru.honn.model;

import java.util.ArrayList;
import java.util.List;

/**
 * Class Borrower (Borrower.java)
 * Data type representing borrowers i.e. friends that have borrowed
 * some tapes along with the tapes they've borrowed
 *
 * @author Edda Steinunn Rúnarsdóttir
 * @version 1.0, 26 Sep 2018
 */
public class Borrower
{
    /**
     * The borrowed tape
     */
    private Friend borrower;
    /**
     * Borrower's tape borrower's name
     */
    private List<BorrowedTape> tapesBorrowed;


    /**
     * Empty constructor
     */
    public Borrower()
    {

    }
    /**
     * Constructs a borrower with empty list of borrowed tapes
     */
    public Borrower(Friend borrower)
    {
        this.borrower = borrower;
        this.tapesBorrowed = new ArrayList<BorrowedTape>();
    }
    /**
     * @return the borrowed tape
     */
    public Friend getBorrower()
    {
        return borrower;
    }
    /**
     * @return id of tape borrower
     */
    public List<BorrowedTape> getTapesBorrowed()
    {
        return tapesBorrowed;
    }
    /**
     * @param tape tape to add to borrower
     */
    public void addTapeToBorrower(BorrowedTape tape)
    {
        tapesBorrowed.add(tape);
    }
    /**
     * @return string representing borrower and list of all his borrowed tapes
     */
    public String toString()
    {
        String borrowerInformation = "", borrowerTapeInformation = "";

        /* output borrower information */
        borrowerInformation += "BORROWER:\n";
        borrowerInformation += "\tID: " + borrower.getId() + "\n";
        borrowerInformation += "\tName: " + borrower.getName() + "\n";
        borrowerInformation += "\tAddress: " + borrower.getAddress() + "\n";
        borrowerInformation += "\tE-mail: " + borrower.getEmail() + "\n";
        borrowerInformation += "\tTelephone: " + borrower.getTelephone() + "\n";

        /* output borrower's borrowed tapes information  */
        borrowerTapeInformation  +=  "TAPES: \n";
        for(int i = 0; i < tapesBorrowed.size(); i++)
        {
            borrowerTapeInformation += "\t" + (i+1) + ". ";
            borrowerTapeInformation += "ID: " + tapesBorrowed.get(i).getId();
            borrowerTapeInformation += ", Title: " + tapesBorrowed.get(i).getTitle();
            borrowerTapeInformation += ", Borrowed On: " + tapesBorrowed.get(i).getBorrowDate();
            borrowerTapeInformation += "\n";
        }

        return borrowerInformation + borrowerTapeInformation;
    }
}