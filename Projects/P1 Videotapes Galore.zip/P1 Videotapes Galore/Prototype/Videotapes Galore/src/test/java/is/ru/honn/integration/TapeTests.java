package is.ru.honn.integration;

import is.ru.honn.factory.TapeServiceFactory;
import is.ru.honn.model.Tape;
import is.ru.honn.service.ConversionService;
import is.ru.honn.service.ResourceNotFoundException;
import is.ru.honn.service.TapeService;
import is.ru.honn.view.MainMenuUI;
import is.ru.honn.view.mainmenu.VideotapesGaloreMainMenuUI;
import org.junit.After;
import org.junit.Assert;
import org.junit.Before;
import org.junit.Test;

import java.io.File;
import java.io.FileNotFoundException;
import java.io.InputStream;
import java.util.Date;
import java.util.Scanner;

public class TapeTests {
    MainMenuUI main = null;
    TapeService tapeService;
    InputStream stream = System.in;

    @Before
    public void beforeEach()
    {
        tapeService = TapeServiceFactory.getTapeService();

    }

    @After
    public void afterEach()
    {
        this.main = null;
        tapeService = null;
        /* calls garbage collector */
        System.gc();
        System.setIn(stream);
    }

    @Test
    public void addTape()
    {
        File file = new File("src/test/java/is/ru/honn/input/AddTapeInput.txt");
        try
        {
            try
            {
                tapeService.getTapeById(2);
                Assert.fail("Tape should not exists in system");
            }
            catch (ResourceNotFoundException e)
            {
                Assert.assertEquals(e.getMessage(), "Tape with id 2 not found");
            }
            Scanner scanner = new Scanner(file);
            main = new VideotapesGaloreMainMenuUI(scanner);
            main.start();

            /* The tape is automatically read from scanner since it uses the file stream */
            Tape tapeReceived = tapeService.getTapeById(1);
            Date expectedReleaseDate = ConversionService.stringToDate("1985-12-12");
            Tape tapeExpected = new Tape(2, "Back to the Future", "Robert Zemeckis", "VHS", expectedReleaseDate, "10.5240/4676-53B7-F70F-7C41-0674-3");
            Assert.assertEquals(tapeReceived.getTitle(), tapeExpected.getTitle());
            Assert.assertEquals(tapeReceived.getDirector(), tapeExpected.getDirector());
            Assert.assertEquals(tapeReceived.getType(), tapeExpected.getType());
            Assert.assertEquals(tapeReceived.getReleaseDate(), tapeExpected.getReleaseDate());
            Assert.assertEquals(tapeReceived.getEIDR(), tapeExpected.getEIDR());
        }
        catch (FileNotFoundException e)
        {
            Assert.fail("Invalid filepath read for addTape testcase");
        }
    }

    @Test
    public void attemptAddInvalidType()
    {
        File file = new File("src/test/java/is/ru/honn/input/AddTapeInvalidTypeInput.txt");
        assertTapeNotCreated(file);
    }

    @Test
    public void attemptAddInvalidDate()
    {
        File file = new File("src/test/java/is/ru/honn/input/AddTapeInvalidDateInput.txt");
        assertTapeNotCreated(file);
    }

    private void assertTapeNotCreated(File file)
    {
        try
        {
            try
            {
                tapeService.getTapeById(3);
                Assert.fail("Friend should not exists in system");
            }
            catch (ResourceNotFoundException e)
            {
                Assert.assertEquals(e.getMessage(), "Tape with id 3 not found");
            }
            Scanner scanner = new Scanner(file);
            main = new VideotapesGaloreMainMenuUI(scanner);
            main.start();
            try
            {
                tapeService.getTapeById(3);
                Assert.fail("Tape should not exists in system");
            }
            catch (ResourceNotFoundException e)
            {
                Assert.assertEquals(e.getMessage(), "Tape with id 3 not found");
            }
        }
        catch (FileNotFoundException e)
        {
            Assert.fail("Invalid filepath read for addTape testcase");
        }
    }

}
